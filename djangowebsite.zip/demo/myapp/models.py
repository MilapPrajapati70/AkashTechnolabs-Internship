from django.db import models

# Create your models here.
class Milap(models.Model):
    # name = models.CharField(max_length=100)
    # desc = models.TextField()
    # price = models.IntegerField()
    # offer = models.BooleanField(default=False)
        fname = models.CharField(max_length=200)
        lname = models.CharField(max_length=200)
        email = models.EmailField(max_length=200)
        phone= models.EmailField(max_length=200)
        password = models.CharField(max_length=200)
        birthday = models.CharField(max_length=200)
        gender = models.CharField(max_length=200)
        college= models.CharField(max_length=200)
        course = models.CharField(max_length=200)
        
