
from django.shortcuts import render
from django.http import HttpResponse
from myapp.models import Milap

def homepageview(request):
    return render(request,'home.html')


def aboutpageview(request):
    return render(request,'about.html')

def contactpageview(request):
    return render(request,'contact.html')

def myform(request):
    if request.method == 'POST':
        fname = str(request.POST['fname'])
        lname = str(request.POST['lname'])
        email = str(request.POST['email'])
        phone = str(request.POST['phone'])
        password = str(request.POST['password'])
        birthday = str(request.POST['birthday'])
        gender = (request.POST['gender'])
        college = str(request.POST['college'])
        course = str(request.POST['course'])

        print(fname,lname,email,phone,password,birthday,gender,college,course)

        ins = Milap(fname=fname,lname=lname,email=email,phone=phone,password=password,
                      birthday=birthday,gender=gender,college=college,course=course)

        ins.save()
        print("Data stored successfully")
        
    return render(request,'myform.html')

# def process(request):
#     print("welcome")
#     print(request.method)
#     print(request.POST)
#     first = str(request.POST['fname'])
#     last = str(request.POST['lname'])
#     email = str(request.POST['email'])
#     phone = str(request.POST['phone'])
#     password = str(request.POST['password'])
#     Birthday = str(request.POST['birthday'])
#     gender = (request.POST['gender'])
#     college = str(request.POST['college'])
#     course = str(request.POST['course'])
#     return render(request,'ans.html',{'fname':first,'lname':last,'email':email,'myf':password,
#                 'phone':phone,'birthday':Birthday,'gender':gender,'college':college,'course':course})



